module.exports = {
  // Your Next.js configuration goes here
};
